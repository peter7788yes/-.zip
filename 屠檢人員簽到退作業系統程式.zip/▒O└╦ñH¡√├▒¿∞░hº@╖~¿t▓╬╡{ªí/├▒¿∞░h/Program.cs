using System;
using System.Deployment.Application;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace 簽到退
{
	internal static class Program
	{
		private const string VERSION = "3.3.2.8";

		private static bool _IsHyweb;

		[CompilerGenerated]
		private static bool _003CIsDeployClickOnce_003Ek__BackingField;

		[CompilerGenerated]
		private static bool _003CUpgraded_003Ek__BackingField;

		[CompilerGenerated]
		private static string _003CClickOnceUpdateDN_003Ek__BackingField;

		[CompilerGenerated]
		private static int _003CCounter_003Ek__BackingField;

		public static bool IsDeployClickOnce
		{
			[CompilerGenerated]
			get
			{
				return _003CIsDeployClickOnce_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CIsDeployClickOnce_003Ek__BackingField = value;
			}
		}

		public static bool Upgraded
		{
			[CompilerGenerated]
			get
			{
				return _003CUpgraded_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CUpgraded_003Ek__BackingField = value;
			}
		}

		public static string ClickOnceUpdateDN
		{
			[CompilerGenerated]
			get
			{
				return _003CClickOnceUpdateDN_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CClickOnceUpdateDN_003Ek__BackingField = value;
			}
		}

		public static int Counter
		{
			[CompilerGenerated]
			get
			{
				return _003CCounter_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CCounter_003Ek__BackingField = value;
			}
		}

		[STAThread]
		private static void Main()
		{
			IsDeployClickOnce = true;
			ClickOnceUpdateDN = (_IsHyweb ? "mhr.hyweb.com.tw" : "mi.baphiq.gov.tw");
			Counter = 0;
			Upgraded = false;
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			if (ApplicationDeployment.CurrentDeployment.IsFirstRun)
			{
				CommUtil.WriteToFile("Config.ini", "\r\nMDBPath=" + ApplicationDeployment.CurrentDeployment.DataDirectory, 'A', string.Empty);
				copyShortcut("屠檢人員簽到退作業系統", "屠檢人員簽到退作業系統.appref-ms", "屠檢人員簽到退作業系統(V3.3.2.8版).appref-ms");
				CollectPreviousFiles();
				try
				{
					File.Delete(ApplicationDeployment.CurrentDeployment.DataDirectory + "\\log.txt");
				}
				catch
				{
				}
			}
			if (!File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + "\\Common Files\\MSSoap\\Binaries\\MSSOAP30.dll"))
			{
				MessageBox.Show("您尚未安裝過SOAP, 現在開始安裝。");
				Process process = Process.Start("soapsdk.exe");
				while (!process.HasExited)
				{
					Application.DoEvents();
					process.WaitForExit(50);
				}
			}
			Application.Run(new frmUpdate());
			if (Upgraded)
			{
				Application.Restart();
			}
		}

		private static void copyShortcut(string manufacturerName, string shortcutFileName, string newShortCutName)
		{
			string destFileName = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + newShortCutName;
			string sourceFileName = Environment.GetFolderPath(Environment.SpecialFolder.Programs) + "\\" + manufacturerName + "\\" + shortcutFileName;
			try
			{
				File.Copy(sourceFileName, destFileName, true);
			}
			catch (Exception)
			{
			}
		}

		private static void CollectPreviousFiles()
		{
			string dataDirectory = ApplicationDeployment.CurrentDeployment.DataDirectory;
			string directoryName = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
			try
			{
				if (!Directory.Exists(dataDirectory + "\\Bmp"))
				{
					Directory.CreateDirectory(dataDirectory + "\\Bmp");
				}
				if (!Directory.Exists(dataDirectory + "\\Pic"))
				{
					Directory.CreateDirectory(dataDirectory + "\\Pic");
				}
				if (!Directory.Exists(dataDirectory + "\\SignFeature"))
				{
					Directory.CreateDirectory(dataDirectory + "\\SignFeature");
				}
				if (!Directory.Exists(dataDirectory + "\\srdata"))
				{
					Directory.CreateDirectory(dataDirectory + "\\srdata");
				}
				string[] directories = Directory.GetDirectories(Directory.GetParent(directoryName).ToString());
				string[] array = directories;
				foreach (string str in array)
				{
					if (Directory.Exists(str + "\\Bmp"))
					{
						CopyAllFiles(str + "\\Bmp", dataDirectory + "\\Bmp");
					}
					if (Directory.Exists(str + "\\Pic"))
					{
						CopyAllFiles(str + "\\Pic", dataDirectory + "\\Pic");
					}
					if (Directory.Exists(str + "\\SignFeature"))
					{
						CopyAllFiles(str + "\\SignFeature", dataDirectory + "\\SignFeature");
					}
					if (Directory.Exists(str + "\\srdata"))
					{
						CopyAllFiles(str + "\\srdata", dataDirectory + "\\srdata");
					}
				}
			}
			catch (Exception)
			{
			}
		}

		private static void CopyAllFiles(string srcDir, string dstDir)
		{
			try
			{
				string[] files = Directory.GetFiles(srcDir, "*.*");
				if (files.Length > 0)
				{
					string[] array = files;
					foreach (string text in array)
					{
						File.Copy(text, text.Replace(srcDir, dstDir));
					}
				}
			}
			catch (Exception)
			{
			}
		}
	}
}
